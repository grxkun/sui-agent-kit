// ─────────────────────────────────────────────────────────────────────────────
// x402.ts — HTTP 402 payment SDK (wraps sui_x402.move)
// ─────────────────────────────────────────────────────────────────────────────

import { SuiClient } from '@mysten/sui/client';
import { Transaction } from '@mysten/sui/transactions';
import type { Keypair } from '@mysten/sui/cryptography';
import type { CreatePaymentRequestParams, PaymentRequest, Receipt } from './types.js';

const CLOCK = '0x6';

function toBytes(s: string): number[] {
  return Array.from(new TextEncoder().encode(s));
}

export async function createPaymentRequest(
  params: CreatePaymentRequestParams,
  signer: Keypair,
  client: SuiClient,
  packageId: string,
) {
  const tx = new Transaction();

  tx.moveCall({
    target: `${packageId}::sui_x402::create_request`,
    arguments: [
      tx.pure.vector('u8', toBytes(params.resourceUri)),
      tx.pure.u64(params.amount),
      tx.pure.address(params.recipient),
      tx.pure.u64(params.ttlMs ?? 300_000n),
      tx.object(CLOCK),
    ],
  });

  return client.signAndExecuteTransaction({
    signer,
    transaction: tx,
    options: { showEffects: true, showObjectChanges: true },
  });
}

export async function fulfillRequest(
  requestId: string,
  signer: Keypair,
  client: SuiClient,
  packageId: string,
) {
  // Fetch request to get amount
  const obj = await client.getObject({
    id: requestId,
    options: { showContent: true },
  });

  const fields = (obj.data?.content as any)?.fields;
  const amount = BigInt(fields?.amount ?? 0);

  const tx = new Transaction();
  const [payment] = tx.splitCoins(tx.gas, [Number(amount)]);

  tx.moveCall({
    target: `${packageId}::sui_x402::fulfill`,
    arguments: [tx.object(requestId), payment, tx.object(CLOCK)],
  });

  return client.signAndExecuteTransaction({
    signer,
    transaction: tx,
    options: { showEffects: true, showObjectChanges: true },
  });
}

export async function verifyReceipt(
  client: SuiClient,
  receiptId: string,
  requestId: string,
): Promise<boolean> {
  try {
    const receiptObj = await client.getObject({
      id: receiptId,
      options: { showContent: true },
    });
    const rf = (receiptObj.data?.content as any)?.fields;
    return rf?.request_id === requestId && BigInt(rf?.amount ?? 0) > 0n;
  } catch {
    return false;
  }
}

/**
 * Express-style middleware for auto-paying 402 responses.
 * Usage: app.use(kit.payments.middleware({ maxAmount: 100_000_000 }));
 */
export function sui402Middleware(options: { maxAmount: number }) {
  return (req: any, res: any, next: any) => {
    // Attach x402 headers for downstream handlers
    res.setHeader('X-402-Max-Amount', options.maxAmount.toString());
    res.setHeader('X-402-Token', 'SUI');
    next();
  };
}
