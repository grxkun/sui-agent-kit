/// sui_task_market — On-chain task marketplace with reputation gating.
module sui_agent_kit::sui_task_market {
    use sui::object::{Self, UID};
    use sui::tx_context::{Self, TxContext};
    use sui::transfer;
    use sui::event;
    use sui::clock::{Self, Clock};
    use sui::balance::{Self, Balance};
    use sui::coin::{Self, Coin};
    use sui::sui::SUI;
    use std::string::{Self, String};

    // ===== Error codes =====
    const E_NOT_POSTER: u64 = 0;
    const E_NOT_OPEN: u64 = 1;
    const E_NOT_CLAIMED: u64 = 2;
    const E_NOT_FULFILLED: u64 = 3;
    const E_NOT_ASSIGNED: u64 = 4;
    const E_INSUFFICIENT_REPUTATION: u64 = 5;
    const E_MISSING_CAPABILITY: u64 = 6;
    const E_DEADLINE_PASSED: u64 = 7;
    const E_INSUFFICIENT_REWARD: u64 = 8;

    // ===== Status =====
    const STATUS_OPEN: u8 = 0;
    const STATUS_CLAIMED: u8 = 1;
    const STATUS_FULFILLED: u8 = 2;
    const STATUS_DISPUTED: u8 = 3;
    const STATUS_CANCELLED: u8 = 4;

    // ===== Objects =====

    /// Shared task board.
    public struct TaskBoard has key {
        id: UID,
        open_tasks: u64,
        total_tasks: u64,
    }

    /// A task with escrowed reward.
    public struct Task has key, store {
        id: UID,
        poster: address,
        title: String,
        description_blob: String,
        reward: Balance<SUI>,
        required_capability: String,
        min_reputation_score: u64,
        deadline_epoch: u64,
        status: u8,
        assigned_agent: address,
        result_blob: String,
    }

    // ===== Events =====

    public struct TaskPosted has copy, drop {
        task_id: address,
        poster: address,
        title: String,
        reward: u64,
    }

    public struct TaskClaimed has copy, drop {
        task_id: address,
        agent: address,
    }

    public struct TaskFulfilled has copy, drop {
        task_id: address,
        result_blob: String,
    }

    public struct TaskAccepted has copy, drop {
        task_id: address,
        reward_released: u64,
    }

    public struct TaskDisputed has copy, drop {
        task_id: address,
        poster: address,
    }

    // ===== Init =====

    fun init(ctx: &mut TxContext) {
        let board = TaskBoard {
            id: object::new(ctx),
            open_tasks: 0,
            total_tasks: 0,
        };
        transfer::share_object(board);
    }

    // ===== Public functions =====

    /// Post a new task with escrowed SUI reward.
    public entry fun post_task(
        board: &mut TaskBoard,
        title: vector<u8>,
        description_blob: vector<u8>,
        reward: Coin<SUI>,
        required_capability: vector<u8>,
        min_reputation_score: u64,
        deadline_epoch: u64,
        ctx: &mut TxContext,
    ) {
        let reward_value = coin::value(&reward);
        assert!(reward_value > 0, E_INSUFFICIENT_REWARD);

        let poster = tx_context::sender(ctx);

        let task = Task {
            id: object::new(ctx),
            poster,
            title: string::utf8(title),
            description_blob: string::utf8(description_blob),
            reward: coin::into_balance(reward),
            required_capability: string::utf8(required_capability),
            min_reputation_score,
            deadline_epoch,
            status: STATUS_OPEN,
            assigned_agent: @0x0,
            result_blob: string::utf8(b""),
        };

        let task_addr = object::uid_to_address(&task.id);
        board.open_tasks = board.open_tasks + 1;
        board.total_tasks = board.total_tasks + 1;

        event::emit(TaskPosted {
            task_id: task_addr,
            poster,
            title: task.title,
            reward: reward_value,
        });

        transfer::share_object(task);
    }

    /// Claim an open task (agent checks happen off-chain via SDK for now).
    public entry fun claim_task(
        board: &mut TaskBoard,
        task: &mut Task,
        ctx: &mut TxContext,
    ) {
        assert!(task.status == STATUS_OPEN, E_NOT_OPEN);

        let current_epoch = tx_context::epoch(ctx);
        assert!(current_epoch <= task.deadline_epoch, E_DEADLINE_PASSED);

        let agent = tx_context::sender(ctx);
        task.assigned_agent = agent;
        task.status = STATUS_CLAIMED;
        board.open_tasks = board.open_tasks - 1;

        event::emit(TaskClaimed {
            task_id: object::uid_to_address(&task.id),
            agent,
        });
    }

    /// Fulfill a claimed task with a result.
    public entry fun fulfill_task(
        task: &mut Task,
        result_blob: vector<u8>,
        ctx: &mut TxContext,
    ) {
        assert!(task.status == STATUS_CLAIMED, E_NOT_CLAIMED);
        assert!(task.assigned_agent == tx_context::sender(ctx), E_NOT_ASSIGNED);

        task.result_blob = string::utf8(result_blob);
        task.status = STATUS_FULFILLED;

        event::emit(TaskFulfilled {
            task_id: object::uid_to_address(&task.id),
            result_blob: task.result_blob,
        });
    }

    /// Accept a fulfilled task — releases escrowed reward to agent.
    public entry fun accept_result(
        task: &mut Task,
        ctx: &mut TxContext,
    ) {
        assert!(task.poster == tx_context::sender(ctx), E_NOT_POSTER);
        assert!(task.status == STATUS_FULFILLED, E_NOT_FULFILLED);

        let reward_amount = balance::value(&task.reward);
        let reward_coin = coin::from_balance(
            balance::split(&mut task.reward, reward_amount),
            ctx,
        );

        event::emit(TaskAccepted {
            task_id: object::uid_to_address(&task.id),
            reward_released: reward_amount,
        });

        transfer::public_transfer(reward_coin, task.assigned_agent);
    }

    /// Dispute a fulfilled task (poster only).
    public entry fun dispute_task(
        task: &mut Task,
        ctx: &mut TxContext,
    ) {
        assert!(task.poster == tx_context::sender(ctx), E_NOT_POSTER);
        assert!(task.status == STATUS_FULFILLED, E_NOT_FULFILLED);

        task.status = STATUS_DISPUTED;

        event::emit(TaskDisputed {
            task_id: object::uid_to_address(&task.id),
            poster: task.poster,
        });
    }

    /// Cancel an open task and refund (poster only).
    public entry fun cancel_task(
        board: &mut TaskBoard,
        task: &mut Task,
        ctx: &mut TxContext,
    ) {
        assert!(task.poster == tx_context::sender(ctx), E_NOT_POSTER);
        assert!(task.status == STATUS_OPEN, E_NOT_OPEN);

        task.status = STATUS_CANCELLED;
        board.open_tasks = board.open_tasks - 1;

        let refund_amount = balance::value(&task.reward);
        if (refund_amount > 0) {
            let refund = coin::from_balance(
                balance::split(&mut task.reward, refund_amount),
                ctx,
            );
            transfer::public_transfer(refund, task.poster);
        };
    }

    // ===== View =====

    public fun task_status(task: &Task): u8 { task.status }
    public fun task_poster(task: &Task): address { task.poster }
    public fun task_reward(task: &Task): u64 { balance::value(&task.reward) }
    public fun task_assigned_agent(task: &Task): address { task.assigned_agent }
    public fun board_open_tasks(board: &TaskBoard): u64 { board.open_tasks }
    public fun board_total_tasks(board: &TaskBoard): u64 { board.total_tasks }
}
