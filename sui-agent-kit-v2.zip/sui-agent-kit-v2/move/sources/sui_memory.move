/// sui_memory — Walrus-anchored agent memory layer.
/// On-chain MemoryAnchor with integrity hash pointing to Walrus blobs.
module sui_agent_kit::sui_memory {
    use sui::object::{Self, UID};
    use sui::tx_context::{Self, TxContext};
    use sui::transfer;
    use sui::event;
    use sui::clock::{Self, Clock};
    use std::string::{Self, String};
    use std::vector;

    // ===== Error codes =====
    const E_NOT_OWNER: u64 = 0;
    const E_INVALID_TYPE: u64 = 1;
    const E_HASH_MISMATCH: u64 = 2;

    // ===== Memory types =====
    const MEMORY_EPISODIC: u8 = 0;
    const MEMORY_SEMANTIC: u8 = 1;
    const MEMORY_WORKING: u8 = 2;
    const MEMORY_PROCEDURAL: u8 = 3;

    // ===== Objects =====

    /// An anchor to a Walrus-stored memory blob.
    public struct MemoryAnchor has key, store {
        id: UID,
        agent_id: address,
        memory_type: u8,
        /// Walrus blob ID
        blob_id: String,
        /// SHA-256 hash of the blob content for integrity verification
        content_hash: vector<u8>,
        epoch: u64,
        public_readable: bool,
        tags: vector<String>,
        created_at: u64,
    }

    /// Per-agent memory index tracking anchors.
    public struct MemoryIndex has key, store {
        id: UID,
        agent_id: address,
        anchor_count: u64,
    }

    // ===== Events =====

    public struct MemoryStored has copy, drop {
        anchor_id: address,
        agent_id: address,
        memory_type: u8,
        blob_id: String,
        timestamp: u64,
    }

    public struct MemoryVerified has copy, drop {
        anchor_id: address,
        valid: bool,
    }

    // ===== Public functions =====

    /// Create a memory index for an agent.
    public entry fun create_index(
        agent_id: address,
        ctx: &mut TxContext,
    ) {
        let index = MemoryIndex {
            id: object::new(ctx),
            agent_id,
            anchor_count: 0,
        };
        transfer::share_object(index);
    }

    /// Store a memory anchor pointing to a Walrus blob.
    public entry fun store_memory(
        index: &mut MemoryIndex,
        agent_id: address,
        memory_type: u8,
        blob_id: vector<u8>,
        content_hash: vector<u8>,
        public_readable: bool,
        tags: vector<vector<u8>>,
        clock: &Clock,
        ctx: &mut TxContext,
    ) {
        assert!(memory_type <= 3, E_INVALID_TYPE);
        assert!(index.agent_id == agent_id, E_NOT_OWNER);

        let now = clock::timestamp_ms(clock);
        let current_epoch = tx_context::epoch(ctx);

        // Convert tags
        let mut tag_strings = vector::empty<String>();
        let mut i = 0;
        let len = vector::length(&tags);
        while (i < len) {
            vector::push_back(&mut tag_strings, string::utf8(*vector::borrow(&tags, i)));
            i = i + 1;
        };

        let blob_str = string::utf8(blob_id);

        let anchor = MemoryAnchor {
            id: object::new(ctx),
            agent_id,
            memory_type,
            blob_id: blob_str,
            content_hash,
            epoch: current_epoch,
            public_readable,
            tags: tag_strings,
            created_at: now,
        };

        let anchor_addr = object::uid_to_address(&anchor.id);
        index.anchor_count = index.anchor_count + 1;

        event::emit(MemoryStored {
            anchor_id: anchor_addr,
            agent_id,
            memory_type,
            blob_id: anchor.blob_id,
            timestamp: now,
        });

        if (public_readable) {
            transfer::share_object(anchor);
        } else {
            transfer::transfer(anchor, tx_context::sender(ctx));
        };
    }

    /// Verify a memory anchor's content hash matches expected.
    public fun verify_integrity(
        anchor: &MemoryAnchor,
        expected_hash: &vector<u8>,
    ): bool {
        &anchor.content_hash == expected_hash
    }

    // ===== View =====

    public fun anchor_agent(anchor: &MemoryAnchor): address { anchor.agent_id }
    public fun anchor_type(anchor: &MemoryAnchor): u8 { anchor.memory_type }
    public fun anchor_blob_id(anchor: &MemoryAnchor): &String { &anchor.blob_id }
    public fun anchor_hash(anchor: &MemoryAnchor): &vector<u8> { &anchor.content_hash }
    public fun anchor_epoch(anchor: &MemoryAnchor): u64 { anchor.epoch }
    public fun anchor_public(anchor: &MemoryAnchor): bool { anchor.public_readable }
    public fun anchor_tags(anchor: &MemoryAnchor): &vector<String> { &anchor.tags }
    public fun index_count(index: &MemoryIndex): u64 { index.anchor_count }
}
