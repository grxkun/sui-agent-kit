# sui-agent-kit — Copilot Instructions

## Project context
Monolithic repo with Move smart contracts (move/) and a unified TypeScript SDK (sdk/).
8 composable modules powering the Agentic Economy on Sui.

## Module map
| Move module          | SDK file       | Purpose                                 |
| -------------------- | -------------- | --------------------------------------- |
| sui_agent_id.move    | agent.ts       | Agent identity registry (ERC-8004 eq.)  |
| sui_agent_policy.move| policy.ts      | Delegation caps (Google AP2 eq.)        |
| sui_x402.move        | x402.ts        | HTTP 402 payment protocol               |
| sui_reputation.move  | reputation.ts  | Stake-weighted reputation + attestations|
| sui_task_market.move | task.ts        | Task marketplace with escrow            |
| sui_stream.move      | stream.ts      | Epoch-based streaming payments          |
| sui_a2a.move         | a2a.ts         | Agent-to-agent messaging                |
| sui_memory.move      | memory.ts      | Walrus-anchored memory layer            |

## Move conventions
- All modules under `sui_agent_kit` address
- VecSet for capabilities, Balance<SUI> for escrow
- Events emitted for every state mutation
- Error codes as constants: `const E_NOT_OWNER: u64 = 0;`

## SDK conventions
- Unified entry: `SuiAgentKit` class with `.agents`, `.policies`, `.payments`, etc.
- Each sub-module is a standalone file exporting free functions
- Types mirror Move structs with bigint for u64 fields
- `@mysten/sui` Transaction for all PTB construction
